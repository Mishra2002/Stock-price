import xgboost as xgb
from sklearn.metrics import mean_squared_error

def train_xgboost(X_train, y_train, X_val=None, y_val=None, params=None, num_boost_round=100):
    params = params or {'objective': 'reg:squarederror', 'learning_rate': 0.05, 'max_depth': 4}
    dtrain = xgb.DMatrix(X_train, label=y_train)
    evals = [(dtrain, 'train')]
    deval = None
    if X_val is not None:
        deval = xgb.DMatrix(X_val, label=y_val)
        evals.append((deval, 'valid'))
    model = xgb.train(params, dtrain, num_boost_round=num_boost_round, evals=evals, verbose_eval=False)
    return model

def predict_xgboost(model, X):
    d = xgb.DMatrix(X)
    return model.predict(d)
