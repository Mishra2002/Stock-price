import numpy as np

def ensemble_average(preds_list, weights=None):
    # preds_list: list of numpy arrays with same shape
    if weights is None:
        weights = [1.0/len(preds_list)] * len(preds_list)
    preds = np.zeros_like(preds_list[0])
    for p, w in zip(preds_list, weights):
        preds += p * w
    return preds
