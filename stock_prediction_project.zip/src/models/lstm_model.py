import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping

def build_lstm(input_shape, units=64, dropout=0.2):
    model = Sequential()
    model.add(LSTM(units, input_shape=input_shape, return_sequences=False))
    model.add(Dropout(dropout))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')
    return model

def prepare_sequences(df, feature_cols, window=20):
    X, y = [], []
    data = df[feature_cols].values
    for i in range(window, len(data)):
        X.append(data[i-window:i])
        y.append(data[i, feature_cols.index('Close')])  # predict scaled Close
    X = np.array(X); y = np.array(y)
    return X, y

def train_lstm(model, X_train, y_train, X_val=None, y_val=None, epochs=50, batch_size=16):
    callbacks = [EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)]
    if X_val is None:
        model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=1)
    else:
        model.fit(X_train, y_train, validation_data=(X_val, y_val),
                  epochs=epochs, batch_size=batch_size, verbose=1, callbacks=callbacks)
    return model
