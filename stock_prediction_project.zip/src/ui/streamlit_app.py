import streamlit as st
import pandas as pd
from pathlib import Path
from ..data_preprocessing import load_data, basic_clean
from ..feature_engineering import add_technical_indicators

st.title('Stock Prediction - Demo UI')
uploaded_file = st.file_uploader('Upload OHLCV CSV', type=['csv'])
if uploaded_file is not None:
    df = pd.read_csv(uploaded_file, parse_dates=['Date'])
    st.dataframe(df.tail())
    df = basic_clean(df)
    df = add_technical_indicators(df)
    st.line_chart(df[['Close','ma_5','ma_10']].set_index(df['Date']))
    st.write('Indicators sample:')
    st.dataframe(df[['Date','Close','rsi_14','atr_14','obv']].tail())
else:
    st.info('Upload a CSV file to get started. A sample is included at data/sample_ohlcv.csv')
