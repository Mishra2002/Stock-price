from fastapi import FastAPI, UploadFile, File
import pandas as pd
from pathlib import Path
from ..data_preprocessing import load_data, basic_clean
from ..feature_engineering import add_technical_indicators, create_lag_features

app = FastAPI(title='Stock Prediction API')

@app.post('/upload_and_predict/')
async def upload_and_predict(file: UploadFile = File(...)):
    contents = await file.read()
    tmp = Path('data/tmp_upload.csv')
    tmp.write_bytes(contents)
    df = load_data(str(tmp))
    df = basic_clean(df)
    df = add_technical_indicators(df)
    df = create_lag_features(df)
    # For the demo API we just return last rows and indicators
    last = df.tail(5).to_dict(orient='records')
    return {'last_rows': last, 'note': 'This endpoint prepares data; integrate model prediction as needed.'}
