import numpy as np
import pandas as pd

def simple_strategy_signals(preds, threshold=0.0):
    # preds: predicted next-day returns or price differences
    # Buy (1) if pred > threshold; Sell (-1) if pred < -threshold; else 0
    signals = []
    for p in preds:
        if p > threshold:
            signals.append(1)
        elif p < -threshold:
            signals.append(-1)
        else:
            signals.append(0)
    return np.array(signals)

def backtest_from_signals(df, signals, capital=10000, fee=0.0):
    # df must include 'Close' and be aligned with signals (signals length == df length - window)
    prices = df['Close'].values[-len(signals):]
    positions = signals  # 1 for long, -1 for short (we'll treat short as 0 for this simple backtest)
    cash = capital
    holdings = 0.0
    equity_curve = []
    for i, pos in enumerate(positions):
        price = prices[i]
        # simple: go all-in for buy signals, go to cash for sell/hold
        if pos == 1 and holdings == 0:
            holdings = cash / price
            cash = 0
        elif pos != 1 and holdings > 0:
            cash = holdings * price
            holdings = 0
        total = cash + holdings * price
        equity_curve.append(total)
    # If still holding at end, compute final value
    if holdings > 0:
        cash = holdings * prices[-1]
        holdings = 0
    results = pd.DataFrame({'equity': equity_curve})
    results['returns'] = results['equity'].pct_change().fillna(0)
    # Sharpe Ratio (annualized approximation)
    sharpe = (results['returns'].mean() / (results['returns'].std() + 1e-9)) * (252 ** 0.5)
    # Max drawdown
    cum = results['equity'].cummax()
    drawdown = (results['equity'] - cum) / cum
    max_dd = drawdown.min()
    total_return = results['equity'].iloc[-1] / (capital) - 1
    return {'equity_curve': results, 'sharpe': sharpe, 'max_drawdown': max_dd, 'total_return': total_return}
