import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from .data_preprocessing import load_data, basic_clean, create_scaler, scale_features, train_val_test_split
from .feature_engineering import add_technical_indicators, create_lag_features
from .models.lstm_model import build_lstm, prepare_sequences, train_lstm
from .models.xgboost_model import train_xgboost, predict_xgboost
from .models.hybrid_model import ensemble_average
from .backtesting import simple_strategy_signals, backtest_from_signals
from .visualization import plot_price_vs_pred

def demo_run(data_path):
    df = load_data(data_path)
    df = basic_clean(df)
    df = add_technical_indicators(df)
    df = create_lag_features(df)
    train, val, test = train_val_test_split(df, test_size=0.2, val_size=0.1)
    feature_cols = ['Open','High','Low','Close','Volume','ma_5','ma_10','rsi_14','atr_14','obv']
    # scaler
    scaler = create_scaler(train, feature_cols)
    train_s = scale_features(train, scaler, feature_cols)
    val_s = scale_features(val, scaler, feature_cols)
    test_s = scale_features(test, scaler, feature_cols)
    # LSTM prepare sequences
    window = 5
    X_train, y_train = prepare_sequences(train_s, feature_cols, window=window)
    # quick LSTM build & train (small epochs for demo)
    lstm = build_lstm(input_shape=(X_train.shape[1], X_train.shape[2]), units=32)
    train_lstm(lstm, X_train, y_train, epochs=5)
    print('Demo LSTM training complete.')
    # XGBoost demo - use tabular features to predict next close
    # Prepare X/y for xgboost (simple)
    X_train_tab = train_s[feature_cols].iloc[window:].values
    y_train_tab = train_s['Close'].iloc[window:].values
    xgb_model = train_xgboost(X_train_tab, y_train_tab, num_boost_round=10)
    print('Demo XGBoost training complete.')
    # Predictions (on test)
    X_test_tab = test_s[feature_cols].values
    preds_xgb = predict_xgboost(xgb_model, X_test_tab)
    # Simple ensembling example (we'll just reuse xgb preds)
    preds_ens = preds_xgb
    # Convert preds back if needed (scaler inverse not shown in demo)
    # Backtesting (very simplified)
    signals = simple_strategy_signals(np.sign(preds_ens - X_test_tab[:, feature_cols.index('Close')]), threshold=0.0)
    bt = backtest_from_signals(test, signals)
    print('Backtest total return:', bt['total_return'], 'Sharpe:', bt['sharpe'], 'MaxDD:', bt['max_drawdown'])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='data/sample_ohlcv.csv')
    parser.add_argument('--mode', type=str, default='demo')
    args = parser.parse_args()
    if args.mode == 'demo':
        demo_run(args.data_path)
