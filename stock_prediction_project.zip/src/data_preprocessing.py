import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def load_data(csv_path, date_col='Date'):
    df = pd.read_csv(csv_path, parse_dates=[date_col])
    df = df.sort_values(date_col).reset_index(drop=True)
    return df

def basic_clean(df):
    # Ensure columns present
    expected = {'Date','Open','High','Low','Close','Volume'}
    if not expected.issubset(set(df.columns)):
        raise ValueError(f'Missing expected columns: {expected - set(df.columns)}')
    df = df.copy()
    df = df.dropna().reset_index(drop=True)
    return df

def create_scaler(df, feature_cols=['Open','High','Low','Close','Volume']):
    scaler = MinMaxScaler()
    scaler.fit(df[feature_cols])
    return scaler

def scale_features(df, scaler, feature_cols=['Open','High','Low','Close','Volume']):
    df_scaled = df.copy()
    df_scaled[feature_cols] = scaler.transform(df[feature_cols])
    return df_scaled

def train_val_test_split(df, test_size=0.1, val_size=0.1):
    n = len(df)
    test_n = int(n * test_size)
    val_n = int(n * val_size)
    train = df.iloc[: n - test_n - val_n].reset_index(drop=True)
    val = df.iloc[n - test_n - val_n: n - test_n].reset_index(drop=True)
    test = df.iloc[n - test_n:].reset_index(drop=True)
    return train, val, test
