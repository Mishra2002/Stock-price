def read_yaml(path):
    import yaml
    with open(path, 'r') as f:
        return yaml.safe_load(f)
