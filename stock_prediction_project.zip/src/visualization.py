import matplotlib.pyplot as plt

def plot_price_vs_pred(df_dates, actual, predicted, title='Price vs Predicted'):
    plt.figure(figsize=(10,4))
    plt.plot(df_dates, actual, label='Actual')
    plt.plot(df_dates, predicted, label='Predicted')
    plt.legend()
    plt.title(title)
    plt.tight_layout()
    plt.show()
