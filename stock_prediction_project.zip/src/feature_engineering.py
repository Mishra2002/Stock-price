import numpy as np
import pandas as pd

def add_technical_indicators(df):
    df = df.copy()
    # Simple returns
    df['return'] = df['Close'].pct_change().fillna(0)
    # Moving averages
    df['ma_5'] = df['Close'].rolling(window=5, min_periods=1).mean()
    df['ma_10'] = df['Close'].rolling(window=10, min_periods=1).mean()
    # Bollinger Bands (20,2)
    df['mb'] = df['Close'].rolling(20, min_periods=1).mean()
    df['stddev'] = df['Close'].rolling(20, min_periods=1).std().fillna(0)
    df['bb_up'] = df['mb'] + 2 * df['stddev']
    df['bb_low'] = df['mb'] - 2 * df['stddev']
    # RSI (14)
    delta = df['Close'].diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.rolling(14, min_periods=1).mean()
    ma_down = down.rolling(14, min_periods=1).mean()
    rs = ma_up / (ma_down + 1e-9)
    df['rsi_14'] = 100 - (100 / (1 + rs))
    # ATR (14)
    high_low = df['High'] - df['Low']
    high_close = np.abs(df['High'] - df['Close'].shift())
    low_close = np.abs(df['Low'] - df['Close'].shift())
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['atr_14'] = tr.rolling(14, min_periods=1).mean()
    # On-balance volume (OBV)
    obv = [0]
    for i in range(1, len(df)):
        if df['Close'].iloc[i] > df['Close'].iloc[i-1]:
            obv.append(obv[-1] + df['Volume'].iloc[i])
        elif df['Close'].iloc[i] < df['Close'].iloc[i-1]:
            obv.append(obv[-1] - df['Volume'].iloc[i])
        else:
            obv.append(obv[-1])
    df['obv'] = obv
    df = df.fillna(0)
    return df

def create_lag_features(df, cols=['Close','Volume'], lags=5):
    df = df.copy()
    for col in cols:
        for lag in range(1, lags+1):
            df[f'{col}_lag_{lag}'] = df[col].shift(lag).fillna(method='bfill')
    return df
